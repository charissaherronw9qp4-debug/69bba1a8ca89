// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("sonarcloud"); }
int main(){
  announce();
  return lionss_run_workload("sonarcloud");
}
